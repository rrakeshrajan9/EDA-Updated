"""
Contains handy utility functions
@author: Haribaskar.D
"""
from pathlib import Path
import os.path
import sys
# import ConfigParser Python 2.x
import configparser
import errno
import math


def is_python3():
    """
    Checks if the python version is 3
    :return:
    """
    return sys.version_info.major == 3


def is_str(obj):
    """
    Checks if the given object is type of string or not
    :param str:
    :return:
    """
    # if is_python3():
    return isinstance(obj, str)  # basestring in Python 2.x


def replace_nan(arr, replace_with=0):
    """
    Replaces the nan in the given array with replace_with
    """
    arr1 = [0 if math.isnan(x) else x for x in arr]
    return arr1


def get_full_path(folder, file):
    if is_python3():
        if is_str(folder):
            folder = Path(folder)
        file_name = folder / file
        file_name = str(file_name)
    else:
        file_name = os.path.join(folder, file)
    return file_name


def get_project_root():
    return os.path.dirname(os.path.abspath(__file__))


def get_project_root_path():
    return Path(os.path.dirname(os.path.abspath(__file__)))


def get_fq_path(folder, *args):
    file_name = folder
    if is_python3():
        if is_str(file_name):
            file_name = Path(file_name)
        for arg in args:
            file_name = file_name / arg
        file_name = str(file_name)
    else:
        for arg in args:
            file_name = os.path.join(file_name, arg)
    return file_name


def construct_fq_path(*args):
    file_name = args[0]
    if is_python3():
        if is_str(file_name):
            file_name = Path(file_name)
        for arg in args[1:]:
            file_name = file_name / arg
        file_name = str(file_name)
    else:
        for arg in args[1:]:
            file_name = os.path.join(file_name, arg)

    # we can also do something like this
    # for arg in args[1:]:
    #    file_name = file_name + os.sep + arg
    return file_name


def get_fq_project_file_path(filename):
    """
    Gets fully qualified path of a file within the project directory
    :param file:
    :return:
    """
    if is_python3():
        file_name = get_project_root_path() / filename
        file_name = str(file_name)
    else:
        file_name = os.path.join(get_project_root(), filename)

    return file_name


def mkpath(path):
    """Alias for mkdir -p."""
    try:
        os.makedirs(path)
    except OSError as exc:
        if exc.errno == errno.EEXIST and os.path.isdir(path):
            pass
        else:
            raise


def mkpath2(path):
    """Alias for mkdir -p."""
    try:
        os.makedirs(path)
    except OSError as e:
        if e.errno == errno.EEXIST and os.path.isdir(path):
            pass
        else:
            return False
    return True


def get_config(config_file):
    """
    Creates a config object from a given config file
    :param config_file:
    :return:
    """
    config_file = get_full_path(get_project_root_path(), config_file)
    config = configparser.ConfigParser()
    config.read(config_file)
    return config


def flatten_dict(dict, sep=","):
    """
    Returns the key values of a dictionary as a string
    :param sep:
    :param groupby_vals:
    :return:
    """
    msg = ""
    for k, v in dict.items():
        msg = msg + str(k) + ":" + str(v) + sep + " "
    trim_len = len(sep) + 1
    msg = msg[:-trim_len]
    return msg


def num_to_word(num):
    """
    Converts a number to its word.
    This is used for Risk Category function naming. As number of Risk Category generally doesn't go beyond 5, we are
    limiting the numbers to 5 here. There are libraries which does this for any given number but creating this simple
     function to avoid any additional dependency.
    :param num:
    :return:
    """
    d = {1: 'one', 2: 'two', 3: 'three', 4: 'four', 5: 'five'}
    return d[num]


def get_key_for_value(dict, value):
    """
    Gets the key of a dictionary for a given value
    :param dict:
    :param value:
    :return:
    """
    for key, val in dict.items():  # for name, age in dictionary.iteritems():  (for Python 2.x)
        if type(val) is list:
            for v in val:
                if v == value:
                    return key
        else:
            if val == value:
                return key


def save_df(df, out_folder, filename):
    """
    Saves the df to the path by creating full path
    """
    file_path = get_full_path(out_folder, filename)
    df.to_csv(file_path, index=False)