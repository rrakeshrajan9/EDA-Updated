"""
Sets up the docx table structure
@author: Haribaskar.D
"""

# Importing the Libraries:
import seaborn as sns
import matplotlib.pyplot as plt
import sys, argparse
import shutil
import missingno as misno
from docx import Document
import os
from docx.enum.text import WD_ALIGN_PARAGRAPH
import time
from utils import *
from docx.shared import Pt
import logging
import pandas as pd
import json
import warnings
warnings.filterwarnings("ignore")
mpl_logger = logging.getLogger('matplotlib')
mpl_logger.setLevel(logging.WARNING)

# Add to PATH variable to make this run from command prompt or Jupyter Notebook
project_path = get_project_root()
if project_path not in sys.path:
    sys.path.append(project_path)

# remove any other handlers. This is done because it is not printing anything
for handler in logging.root.handlers[:]:
    logging.root.removeHandler(handler)

# set up logger
logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.DEBUG)

warnings.filterwarnings("ignore", category=DeprecationWarning)



def docx_table(data=None, document=None, table_heading=None):
    """
    Return the table format of the data to the passed document tag

    :param data: dataframe
    :param document: Initialized document
    :param table_heading: Header name for the Table (ex: Feature Table)
    :return:
    """

    ns = document.add_paragraph()
    ns.add_run(table_heading).bold = True
    t1 = document.add_table(data.shape[0] + 1, data.shape[1])

    # add the header rows.
    for j in range(data.shape[-1]):
        t1.cell(0, j).text = data.columns[j]
        paragraphs = t1.cell(0, j).paragraphs
        paragraph = paragraphs[0]
        run_obj = paragraph.runs
        run = run_obj[0]
        font = run.font
        font.size = Pt(10)  # Font size
        font.name = "Cambria"
        font.bold = True  # making the header to bold

    # add the rest of the data frame
    for i in range(data.shape[0]):
        for j in range(data.shape[-1]):
            t1.cell(i + 1, j).text = str(data.values[i, j])
            paragraphs = t1.cell(i + 1, j).paragraphs
            paragraph = paragraphs[0]
            run_obj = paragraph.runs
            run = run_obj[0]
            font = run.font
            font.size = Pt(10)
            font.name = "Cambria"

    t1.style = 'Table Grid'
    # document.add_page_break()
    return document

def save_plot(directory=None, variable_name=None, ref_name=None):
    """
    Saves the plots to the folder
    :return:
    """
    #plt.xlabel(variable_name)
    file_name = "{}_{}.png".format(variable_name, ref_name)
    path = get_full_path(folder=directory, file=file_name)
    plt.savefig(path)