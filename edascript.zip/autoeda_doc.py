"""
Generates the eda doc
@author: Haribaskar.D
"""

# Importing the Libraries:
import seaborn as sns
import matplotlib.pyplot as plt
import sys, argparse
import shutil
import missingno as misno
from docx import Document
import os
from docx.enum.text import WD_ALIGN_PARAGRAPH
import time
from utils import *
from docx.shared import Pt
import logging
import pandas as pd
import json
import warnings
from docs import *
warnings.filterwarnings("ignore")
mpl_logger = logging.getLogger('matplotlib')
mpl_logger.setLevel(logging.WARNING)

# Add to PATH variable to make this run from command prompt or Jupyter Notebook
project_path = get_project_root()
if project_path not in sys.path:
    sys.path.append(project_path)

# remove any other handlers. This is done because it is not printing anything
for handler in logging.root.handlers[:]:
    logging.root.removeHandler(handler)

# set up logger
logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.DEBUG)

warnings.filterwarnings("ignore", category=DeprecationWarning)

logger = logging.getLogger(__name__)


config = get_config(config_file="app.conf")

# Reading the config file to get the feature list:
Usage = list(json.loads(config.get('kpi', 'Usage')).keys())
Progress = list(json.loads(config.get('kpi', 'Progress')).keys())
Score = list(json.loads(config.get('kpi', 'Exam')).keys())
Other = list(json.loads(config.get('kpi', 'Other')).keys())
Cat = list(json.loads(config.get('kpi', 'Categorical')))
target = config.get('app', 'target')

# Consolidating the numerical and categorical features, which are read from the config file
NUMERICAL_FEATURES = Usage + Progress + Score + Other
CATEGORICAL_FEATURES = Cat + [target]

groupby = json.loads(config.get('app', 'composite_key'))
ID_COL = config.get('app', 'id_col')

def numerical_plot(data=None, plot_feature=None, directory=None, **kwargs):
    """
    Returns the box and distribution plot for numerical data
    :param data: dataframe
    :param plot_feature: column name which needs to be plotted
    :param kwargs:  1. miss_imputation = "drop"
                    2. miss_imputation = "fill" and fill_value = by default (0)
                    3. ref_name = ex: numerical_plot to save the graph

    :return:
    """
    miss_imputation = 'drop'
    fill_value = 0
    ref_name = "dist_box_plt"

    if 'miss_imputation' in kwargs.keys():
        miss_imputation = kwargs['miss_imputation']

    if 'fill_value' in kwargs.keys() and miss_imputation == 'fill':
        fill_value = kwargs['fill_value']

    if 'ref_name' in kwargs.keys():
        ref_name = kwargs['ref_name']

    try:
        f, (ax1, ax2) = plt.subplots(1, 2, figsize=(20, 8))
        if miss_imputation == 'drop':
            _ = data[plot_feature].dropna()
        if miss_imputation == 'fill':
            _ = data[plot_feature].fillna(fill_value)
        sns.boxplot(_, color='orange', ax=ax1)
        sns.distplot(_, ax=ax2)
        save_plot(directory=directory, variable_name=plot_feature, ref_name=ref_name)
        plt.close('all')
    except Exception as e:
        logging.warning("Plotting failed for {} due to {}".format(plot_feature, e))
        plt.close('all')


def categorical_plot(data=None, plot_feature=None, directory=None, **kwargs):
    """
    Returns the bar plot for categorical data
    :param data: dataframe
    :param plot_feature: column name which needs to be plotted
    :param kwargs:  1. miss_imputation = "drop"
                    2. miss_imputation = "fill" and fill_value = by default (0)
                    3. ref_name = ex: numerical_plot to save the graph

    :return:
    """
    # setting the default values to the arguments:
    miss_imputation = 'drop'
    fill_value = 0
    ref_name = "bar_plt"

    if 'miss_imputation' in kwargs.keys():
        miss_imputation = kwargs['miss_imputation']

    if 'fill_value' in kwargs.keys() and miss_imputation == 'fill':
        fill_value = kwargs['fill_value']

    if 'ref_name' in kwargs.keys():
        ref_name = kwargs['ref_name']

    try:
        fig, ax = plt.subplots(figsize=(10, 10))
        if miss_imputation == 'drop':
            _ = data[plot_feature].dropna()
        if miss_imputation == 'fill':
            _ = data[plot_feature].fillna(fill_value)
        sns.countplot(x=plot_feature, data=data, ax=ax)
        save_plot(directory=directory, variable_name=plot_feature, ref_name=ref_name)
        plt.close('all')
    except Exception as e:
        logging.warning("Plotting failed for {} due to {}".format(plot_feature, e))
        plt.close('all')

def correlation_plot(data=None, features=None, directory=None, **kwargs):
    """
    Returns the correlation heat map plot for numerical features
    :param data: dataframe
    :param features: list of numerical features
    :param kwargs:  1. plot_feature = ex: correlation or corr to save the graph
                    2. ref_name = reference to save the plots
    :return:
    """
    # setting the default values to the arguments:
    plot_feature = 'correlation'
    ref_name = "plt"

    if 'plot_feature' in kwargs.keys():
        plot_feature = kwargs['plot_feature']

    if 'ref_name' in kwargs.keys():
        ref_name = kwargs['ref_name']

    try:
        corr = data[features].corr()
        fig, ax = plt.subplots(figsize=(20, 20))
        sns.heatmap(corr,
                    xticklabels=corr.columns,
                    yticklabels=corr.columns, ax=ax)
        save_plot(directory=directory, variable_name=plot_feature, ref_name=ref_name)
        plt.close('all')
    except Exception as e:
        logging.warning('Could not plot the correlation due to: {}'.format(e))
        plt.close('all')


def data_statistics(data=None, features=None):
    """
    Returns the information about the data distribution (as a dataframe)
    :param data: dataframe
    :param features: list of features
    :return:
    """
    stat = data[features].describe().transpose().reset_index()
    stat = round(stat, 0)
    logging.info("Completed - Data statistics ")
    return stat

def target_ratio(data=None, target=None):
    """
    Returning the target ratio.
    :param data: dataframe
    :param target: target feature name
    :return:
    """
    target_ratio = data[target].value_counts().reset_index()
    target_ratio.columns = [target, 'COUNTS']
    target_ratio[target + '%'] = round((target_ratio['COUNTS'] / sum(target_ratio['COUNTS']))*100,2)
    logging.info("Completed - Target Ratio")
    return target_ratio

def missing_summary(data=None):
    """
    Returns the missing value for all the features in the data
    :param data: dataframe
    :return:
    """
    feat = NUMERICAL_FEATURES + CATEGORICAL_FEATURES
    # get the missing count
    missing = pd.DataFrame(data[feat].isnull().sum()).reset_index()
    missing.columns = ['Features', 'Count']
    missing = missing[missing['Count'] > 0].reset_index(drop=True)
    missing['%Missing'] = round(missing['Count']/len(data),2)
    logging.info("Completed - Missing Data Summary")
    return missing

def columns_check(data=None, num_features=None, cat_features=None):
    """
    Returning the valid or the columns which are present in the data
    :param data:
    :return:
    """
    num_features = [i for i in data.columns if i in num_features]
    cat_features = [i for i in data.columns if i in cat_features]
    return num_features, cat_features

def get_population(data=None):
    """
    Return the population information for each group
    :param data: dataframe
    :return:
    """
    # Get the population count for each combination
    population = data.groupby(groupby).agg({ID_COL:'nunique'}).reset_index()
    population.rename(columns={ID_COL: 'NUMBER_OF_USERS'}, inplace=True)
    logging.info("Completed - Population Summary")
    return population

def auto_eda(data=None, report_heading=None, num_features=None, cat_features=None, dir=None):
    """

    :param data: dataframe
    :return:
    """

    directory = dir

    # Structure of the report:

    # Check whether the passed columns are present in the data, if not ignore the missing columns
    num_features, cat_features = columns_check(data=data, num_features=num_features, cat_features=cat_features)

    document = Document()
    # Adding heading to the report
    document.add_heading(report_heading, 0)
    # Descriptive stats introduction
    document.add_heading('Objective', 1)
    # p = document.add_paragraph()
    # p.add_run("Objective:").bold = True
    p = document.add_paragraph()
    p.add_run('Exploratory Data Analysis (EDA) is an approach/philosophy for data analysis that employs a variety of techniques to Understand the distribution of data for different features')
    p = document.add_paragraph()
    p.add_run('1. Descriptive statistics: It gives a brief descriptive coefficients that summarize a given data set, which can be either a representation of the entire or a sample of a population. Descriptive statistics are broken down into measures of central tendency and measures of variability (spread). Measures of central tendency include the mean, median, and mode, while measures of variability include the standard deviation, variance, the minimum and maximum variables, and the kurtosis and skewness.')
    p = document.add_paragraph()
    p.add_run('2. Graphical representation: It is a way of analysing numerical data. It exhibits the relation between data, ideas, information and concepts in a diagram. It is easy to understand and it is one of the most important learning strategies. It always depends on the type of information in a particular domain. Here we have used distibution plot to understand the numerical features and bar plot to understand the categorical features.')
    # About population count
    document.add_heading('Population Summary', 1)
    p = document.add_paragraph()
    p.add_run('The below table contains the user count for each combination.')
    pop = get_population(data=data)
    document = docx_table(data=pop, document=document)
    # Total population
    p = document.add_paragraph()
    p.add_run('Total Population = {}'.format(sum(pop['NUMBER_OF_USERS'])))
    # p = document.add_paragraph()
    # p.add_run("Descriptive statistics:").bold = True
    document.add_heading('Descriptive statistics', 1)
    p = document.add_paragraph()
    p.add_run('The data contains both numerical and categorical columns.')
    p = document.add_paragraph()
    p.add_run("The summary of the column is shown below:")
    # getting the stats for the features
    stat = data_statistics(data=data, features=num_features+cat_features)
    # Adding the stats table to the document
    document = docx_table(data=stat, document=document)
    # Target Summary
    document.add_heading('Target Summary', 1)
    target_summary = target_ratio(data=data, target=target)
    # Adding the Target summary to the document
    document = docx_table(data=target_summary, document=document)
    # missing value summary
    # p.add_run("Missing value summary:").bold = True
    # document.add_heading('Missing value summary', 1)
    # missing = missing_summary(data=data)
    # exporting the missing value summary to the document
    # document = docx_table(data=missing, document=document)
    # saving the categorical plots
    for x in cat_features:
        categorical_plot(data=data, plot_feature=x, directory=directory)
    logging.info("Completed - Categorical plots ")
    # saving the numerical plots
    for y in num_features:
        numerical_plot(data=data, plot_feature=y, directory=directory)
    logging.info("Completed - Numerical plots ")
    # saving the correlation plot:
    correlation_plot(data=data, features=num_features, directory=directory)
    logging.info("Completed - Correlation plots")
    # importing the saved numerical plots to report
    # p = document.add_paragraph()
    # p.add_run("Plots for features").bold = True
    document.add_heading('Plots for features', 1)
    p = document.add_paragraph()
    p.add_run('Plotting the distribution and box-plot to understand about the feature distributions.')
    # getting all the files from the directory
    filelist = os.listdir(directory)
    # getting the image files from the file list
    filelist = [i for i in filelist if any(i.endswith(x) for x in [".png", ".jpeg", ".jpg", ".jpe"])]

    # Importing the numerical plots to report
    for img in filelist:
        if 'dist' in img:
            f = document.add_paragraph()
            f.add_run(img[:-17] + ':').bold = True
            img_path = get_full_path(directory, img)
            my_image = document.add_picture(img_path, width=4555000, height=2200000)
        last_paragraph = document.paragraphs[-1]
        last_paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT

    p = document.add_paragraph()
    p.add_run('Plotting the Bar plot to understand the counts for the categorical variables.')

    # Importing categorical plots to report
    for img in filelist:
        if 'bar' in img:
            f = document.add_paragraph()
            f.add_run(img[:-12] + ':').bold = True
            img_path = get_full_path(directory, img)
            my_image = document.add_picture(img_path, width=2555000, height=2200000)
        last_paragraph = document.paragraphs[-1]
        last_paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT

    # Importing the correlation plot:
    for img in filelist:
        if 'correlation' in img:
            f = document.add_paragraph()
            # f.add_run('Correlation:').bold = True
            document.add_heading('Correlation', 1)
            f = document.add_paragraph()
            f.add_run('Correlation is a statistical technique that can show how strongly pair of variables are related to each other')
            img_path = get_full_path(directory, img)
            my_image = document.add_picture(img_path, width=6500000, height=4000000)
        last_paragraph = document.paragraphs[-1]
        last_paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT

    # saving the report
    file_name = "report.docx"
    outfile_path = get_full_path(directory, file_name)

    document.save(outfile_path)



def parse_args():
    arg_parser = argparse.ArgumentParser(
        description='EDA Report for ExamFX Manager Tracking project'
    )

    arg_parser.add_argument(
        "-F", "--input-file",
        default=None,
        help="Input csv file that contains data to generate the report "
    )

    arg_parser.add_argument(
        "-RH", "--report-heading",
        default=None,
        help="Heading or Tag for the report"
    )

    arg_parser.add_argument(
        "-O", "--out-folder",
        default=None,
        help="File location to store the benchmark data"
    )
    args = arg_parser.parse_args()
    return args


def main():
    """
    A simple tester file
    :return:
    """
    args = parse_args()
    start_time = time.time()
    logging.info("Task started at {} seconds".format(time.strftime("%b %d %Y %H:%M:%S", time.gmtime(start_time))))
    path = args.input_file
    data = pd.read_csv(path)

    # Reading the arguments
    global directory
    if args.out_folder is not None:
        directory = args.out_folder

    report_heading = args.report_heading

    # Generating the Auto EDA Report
    auto_eda(data=data, report_heading=report_heading,
             num_features=NUMERICAL_FEATURES,
             cat_features=CATEGORICAL_FEATURES,
             dir=directory)

    total_time = time.time() - start_time
    logging.info("Task completed in {} seconds".format(total_time))


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (KeyboardInterrupt, EOFError):
        print("\nAborting ... Keyboard Interrupt.")
        sys.exit(1)
